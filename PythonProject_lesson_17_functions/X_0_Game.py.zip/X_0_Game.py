# Хрестики Нулики

# глобальні змінні
# хрестик
# нулик

# функції(підзадачі)
# створення сітки -- list[list[str]]

# добавити новий елемент на сітку(отримує координати та символ)

# спитати користувача куди добавити новий символ(отримує ім'я користувача)
# уточнює якщо клітинка занята

# перевірка(хто виграв)
# варіанти результату
#   * хрестик
#   * нулик
#   * None -- нічия

# перевірка чи гра все ще триває(чи є вільне місце)

# main -- головна функція, організовує вся роботуґзапускає програму


from typing import Literal, Optional

# Тип для символів на сітці
CROSS = "X"
ZERO = "O"
EMPTY = " "
Symbol = Literal["X", "O"]
Cell = Literal["X", "O", " "]  # " " — порожня клітинка


def create_grid(size: int = 3) -> list[list[Cell]]:
    """
    Створює і повертає порожню сітку для гри «Хрестики-нулики».

    :param size: int - Розмір квадратної сітки (типово 3x3)
    :return: list[list[Cell]] - Двовимірний список, що представляє ігрове поле.
             Кожна клітинка містить "X", "O" або " " (пробіл для порожньої).
    """

    grid = list()
    for i in range(size):
        row = list()
        for j in range(size):
            row.append(EMPTY)
        grid.append(row)
    return grid



def print_grid(grid: list[list[Cell]]) -> None:
    """
    Виводить поточний стан сітки на екран у зручному для читання вигляді.

    :param grid: list[list[Cell]] - Поточна сітка гри.
    :return: None
    """
    # ---+---+---
    #    | X | O
    # ---+---+---
    #  O |   | X
    for row in grid:
        print(" "+" | ".join(row)+"  ")
        print("---+"*(len(row)-1), "---", sep="")


def add_symbol_to_grid(
    grid: list[list[Cell]],
    row: int,
    col: int,
    symbol: Symbol
) -> bool:
    """
    Додає новий символ на сітку за вказаними координатами.

    :param grid: list[list[Cell]] - Поточна сітка гри.
    :param row: int - Індекс рядка (0-based).
    :param col: int - Індекс стовпчика (0-based).
    :param symbol: Symbol - Символ гравця ("X" або "O").
    :return: bool - True, якщо хід успішний (клітинка була вільна),
                    False, якщо клітинка вже зайнята або координати некоректні.
    """
    # TODO:
    # 1. Перевірити, що row і col в межах розміру сітки.
    # 2. Перевірити, що в цій клітинці зараз " " (порожньо).
    # 3. Якщо все ок — записати symbol у grid[row][col] і повернути True.
    # 4. Інакше повернути False.


    l = len(grid)
    if row <0 or row >=l or col < 0 or col >= l:
        print("Error, you are outside")
        return False
    if grid[row][col] == " ":
        grid[row][col] = symbol
        return True
    else:
        print("This place is not empty")
        return False


def ask_user_move(player_name: str, grid: list[list[Cell]]) -> tuple[int, int]:
    """
    Запитує у користувача, куди поставити новий символ.

    Повинна:
    - запитати координати (рядок і стовпчик),
    - перевірити, що клітинка вільна,
    - у разі помилки (зайнята/некоректна) — попросити ввести ще раз.

    :param player_name: str - Ім'я поточного гравця (наприклад, "Гравець X").
    :param grid: list[list[Cell]] - Поточна сітка гри.
    :return: tuple[int, int] - Пара (row, col) з коректними координатами для ходу.
    """
    # TODO:
    # 1. В циклі питати в користувача рядок та стовпчик (через input()).
    # 2. Перевіряти:
    #    - чи це числа;
    #    - чи знаходяться в межах сітки;
    #    - чи клітинка вільна.
    # 3. Якщо все добре — повернути (row, col).
    # 4. Якщо ні — вивести повідомлення про помилку і повторити.
    symbol = input("Enter your symbol X or 0 ")
    while has_empty_cells(grid):
        row = int(input(f" {player_name} Enter row "))
        col = int(input(f" {player_name} Enter column "))
        if add_symbol_to_grid(grid, row, col, symbol):
            return (row, col)
            break


def check_winner(grid: list[list[Cell]]) -> Optional[Symbol]:
    """
    Перевіряє, чи є переможець на поточній сітці.

    Перевіряються:
    - усі рядки,
    - усі стовпці,
    - дві діагоналі (головна і побічна).

    :param grid: list[list[Cell]] - Поточна сітка гри.
    :return: Optional[Symbol] - "X", якщо виграв хрестик,
                                "O", якщо виграв нулик,
                                None, якщо переможця ще немає.
    """
    # TODO:
    # 1. Перевірити кожний рядок: всі елементи однакові та не " ".
    # 2. Перевірити кожний стовпець.
    # 3. Перевірити дві діагоналі.
    # 4. Якщо знайдено три однакові символи ("X" або "O") — повернути їх.
    # 5. Якщо переможця немає — повернути None.

    l = len(grid)

    for row in grid:
        first_el = row[0]
        if first_el != EMPTY and all(cell == first_el for cell in row):
            return first_el

    for col in range(l):
        first_el = grid[0][col]
        if first_el != EMPTY and all(grid[row][col] == first_el for row in range(l)):
            return first_el


def has_empty_cells(grid: list[list[Cell]]) -> bool:
    """
    Перевіряє, чи є на сітці ще вільні (порожні) клітинки.

    :param grid: list[list[Cell]] - Поточна сітка гри.
    :return: bool - True, якщо є хоч одна порожня клітинка,
                    False, якщо поле повністю заповнене.
    """
    for row in grid:
        if EMPTY in row:
            return True
    return False


def is_game_over(grid: list[list[Cell]]) -> bool:
    """
    Перевіряє, чи гра завершена.

    Гра завершується, якщо:
    - є переможець, або
    - немає вільних клітинок (нічия).

    :param grid: list[list[Cell]] - Поточна сітка гри.
    :return: bool - True, якщо гра завершена, False інакше.
    """
    # TODO:
    # 1. Використати check_winner().
    # 2. Використати has_empty_cells().
    # 3. Повернути True, якщо є переможець або немає порожніх клітинок.
    pass


def switch_player(player: Symbol) -> Symbol:
    """
    Змінює поточного гравця.

    :param player: Symbol - Поточний символ гравця ("X" або "O").
    :return: Symbol - Інший символ ("O" якщо був "X", і навпаки).
    """
    # TODO: повернути "O" якщо player == "X", і "X" якщо player == "O".
    pass


def main() -> None:
    """
    Головна функція. Організовує всю роботу гри та запускає програму.

    Алгоритм:
    1. Створити порожню сітку.
    2. Встановити стартового гравця (наприклад, "X").
    3. У циклі:
       - вивести сітку;
       - запитати хід у поточного гравця;
       - додати символ до сітки;
       - перевірити, чи є переможець;
       - перевірити, чи ще є вільні клітинки;
       - при завершенні гри вивести результат (хто виграв або нічия);
       - переключити гравця.
    """
    # TODO: реалізувати основний ігровий цикл за описаним алгоритмом.
grid= create_grid(3)
for row in grid:
    print(row)
#
# print_grid(grid)
# print("********************************************")
add_symbol_to_grid(grid,1, 1, "X")
print_grid(grid)
#
# # add_symbol_to_grid(grid,2, 5, "0")
# # add_symbol_to_grid(grid,1, 1, "0")
#

# ask_user_move("Alina", grid)
# print_grid(grid)
# check_winner(grid)